#Author: Sai Santhosh Narendruni
#Id: 700745194

import numpy as np

# Create a random vector of size 20 with float values between 1 and 20
vector = np.random.uniform(1, 20, 20)

# Reshape the array to 4 by 5
vector = vector.reshape(4, 5)
print(vector)
# Replace the max value in each row with 0 (axis=1)
vector[np.arange(4), vector.argmax(axis=1)] = 0

print(vector)